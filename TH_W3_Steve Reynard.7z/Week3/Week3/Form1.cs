﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Week3
{
    public partial class Form1 : Form
    {
        List<string>Nama = new List<string>();
        List<string> Password = new List<string>();
        List<int> Uang = new List<int>();
        int id = 0;

        public Form1()
        {
            InitializeComponent();
            panelmenu.Location = new Point(12, 123);
            panelregister.Location = new Point(12, 123);
            panelwith.Location = new Point(12, 123);
            paneldepo.Location = new Point(12, 123);
            panel1.Location = new Point(12, 123);
            panel1.Visible = true;
        }






        private void labelbalance_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            panelregister.Visible = true;
            panel1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool ada = false;
            foreach(string s in Nama)
            {
                if (textBox4.Text == s)
                {
                    ada = true;
                }
            }
            if (ada)
            {
                MessageBox.Show("Account Already Existed");
            }
            else
            {
                MessageBox.Show("Account Created");
                Nama.Add(textBox4.Text);
                Password.Add(textBox3.Text);
                Uang.Add(0);
            }
            textBox3.Text = "";
            textBox4.Text = "";
            panelregister.Visible = false;
            panel1.Visible = true;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool ada = false ;
            id = -1;
            foreach (string s in Nama)
            {
                id++;
                if (textBox1.Text == s)
                {
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                MessageBox.Show("No Users Found");
            }
            else if (Password[id] == textBox2.Text)
            {
                MessageBox.Show("Welcome");
                panelmenu.Visible = true;
                labelbalance.Text = "Balance : Rp." + Uang[id];
                textBox2.Text = "";
                textBox1.Text = "";
                panel1.Visible = false;
            }
            else
            {
                MessageBox.Show("Wrong Password");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Goodbye");
            panelmenu.Visible = false;
            panel1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            labelbaldepo.Text = "Balance : Rp." + Uang[id];
            panelmenu.Visible = false;
            paneldepo.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            labelbaldraw.Text = "Balance : Rp." + Uang[id];
            panelmenu.Visible = false;
            panelwith.Visible = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int nomer = Convert.ToInt32(textBox5.Text);

            if (nomer < 1)
            {
                MessageBox.Show("Amount cannot be below or equal to 0");
            }
            else
            {
                MessageBox.Show("Deposited Rp." + nomer);
                Uang[id] = Uang[id] + nomer;
            }

            textBox5.Text = "";
            labelbalance.Text = "Balance : Rp." + Uang[id];
            panelmenu.Visible = true;
            paneldepo.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int nomer = Convert.ToInt32(textBox6.Text);

            if (nomer < 1)
            {
                MessageBox.Show("Amount cannot be below or equal to 0");
            }
            else if (Uang[id] < nomer)
            {
                MessageBox.Show("Not enough in balance");
            }
            else
            {
                MessageBox.Show("Withdrawn Rp."+nomer);
                Uang[id] = Uang[id] - nomer;
            }

            textBox6.Text = "";
            labelbalance.Text = "Balance : Rp." + Uang[id];
            panelmenu.Visible = true;
            panelwith.Visible = false;
        }
    }
}
